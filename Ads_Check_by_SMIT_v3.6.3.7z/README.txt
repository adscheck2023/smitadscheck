Step 1: Ads_Check_by_SMIT_v3.6.3.exe
Step 2: Visit chrome://extensions/ and turn on Developer mode
	Load unpacked --> folder Ads_Check_by_SMIT_v3.6.3
